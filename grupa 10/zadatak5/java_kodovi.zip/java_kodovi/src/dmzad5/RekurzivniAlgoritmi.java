package dmzad5;

import java.util.Scanner;

public class RekurzivniAlgoritmi {

    // Metoda za unos broja sa zaštitom za neispravan unos
    public static int unosBroja(Scanner scanner) {
        int n;
        while (true) {
            System.out.print("Unesite pozitivan ceo broj: ");
            if (scanner.hasNextInt()) {
                n = scanner.nextInt();
                if (n >= 0) { // Proveravamo da li je broj nenegativan
                    break; // Izlazimo iz petlje ako je unos ispravan
                } else {
                    System.out.println("Greska! Molimo unesite pozitivan ceo broj.");
                }
            } else {
                System.out.println("Greska! Molimo unesite ceo broj.");
                scanner.next(); // Čistimo neispravan unos
            }
        }
        return n;
    }

    // HANOJSKE KULE

    // Rekurzivna metoda za rešavanje problema Hanojskih kula
    public static void hanoi(int diskovi, char pocetak, char kraj, char pomocni) {
        if (diskovi == 1) {
            System.out.println("Premesti disk 1 sa " + pocetak + " na " + kraj);
            return;
        }
        // Prvi korak: premestamo n-1 diskova sa početnog na pomoćni štap
        hanoi(diskovi - 1, pocetak, pomocni, kraj);
        // Drugi korak: premestamo najveći disk sa početnog na ciljni štap
        System.out.println("Premesti disk " + diskovi + " sa " + pocetak + " na " + kraj);
        // Treći korak: premestamo n-1 diskova sa pomoćnog na ciljni štap
        hanoi(diskovi - 1, pomocni, kraj, pocetak);
    }

    // FIBONACI

    // Rekurzivna metoda za izračunavanje Fibonacijevog broja
    public static int fibonaci(int n) {
        if (n == 0) return 0;      // Baza: fib(0) = 0
        if (n == 1) return 1;      // Baza: fib(1) = 1
        return fibonaci(n - 1) + fibonaci(n - 2);  // Rekurzivni poziv
    }

    // FAKTORIJEL

    // Rekurzivna metoda za izračunavanje faktorijela
    public static long faktorijel(int n) {
        if (n <= 1) return 1;  // Baza: faktorijel 0 i 1 je 1
        return n * faktorijel(n - 1);  // Rekurzivni poziv: n * faktorijel(n - 1)
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Hanojske kule
        System.out.println("===== Hanojske Kule =====");
        System.out.print("Unesite broj diskova: ");
        int brojDiskova = unosBroja(scanner);
        hanoi(brojDiskova, 'A', 'C', 'B');  // Pokrećemo Hanojske kule sa štapovima A, B i C

        // Fibonaci
        System.out.println("\n===== Fibonaci =====");
        System.out.print("Unesite indeks za Fibonacijev broj: ");
        int fibIndeks = unosBroja(scanner);
        System.out.println("Fibonaci broj na poziciji " + fibIndeks + " je " + fibonaci(fibIndeks));

        // Faktorijel
        System.out.println("\n===== Faktorijel =====");
        System.out.print("Unesite broj za faktorijel: ");
        int brojZaFaktorijel = unosBroja(scanner);
        System.out.println("Faktorijel broja " + brojZaFaktorijel + " je " + faktorijel(brojZaFaktorijel));

        scanner.close();
    }
}