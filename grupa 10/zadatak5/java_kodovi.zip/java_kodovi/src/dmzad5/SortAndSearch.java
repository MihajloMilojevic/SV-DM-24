package dmzad5;

import java.util.ArrayList;
import java.util.Scanner;

public class SortAndSearch {

    // Metoda za unos broja elemenata sa zaštitom
    public static int unosBrojaElemenata(Scanner scanner) {
        int n;
        while (true) {
            System.out.print("Unesite broj elemenata niza: ");
            if (scanner.hasNextInt()) {
                n = scanner.nextInt();
                if (n > 0) { // Proveravamo da li je broj pozitivan
                    break;  // Izlazimo iz petlje ako je unos ispravan
                } else {
                    System.out.println("Greska! Unesite pozitivan ceo broj.");
                }
            } else {
                System.out.println("Greska! Unesite broj.");
                scanner.next(); // Čistimo neispravan unos
            }
        }
        return n;
    }

    // Metoda za unos elemenata niza sa zaštitom
    public static ArrayList<Integer> unosElemenata(Scanner scanner, int n) {
        ArrayList<Integer> niz = new ArrayList<>();
        System.out.println("Unesite elemente niza:");
        for (int i = 0; i < n; i++) {
            while (true) {
                System.out.print("Element " + (i + 1) + ": ");
                if (scanner.hasNextInt()) {
                    niz.add(scanner.nextInt());
                    break;  // Izlazimo iz petlje ako je unos ispravan
                } else {
                    System.out.println("Greska! Unesite broj.");
                    scanner.next(); // Čistimo neispravan unos
                }
            }
        }
        return niz;
    }

    // Funkcija za spajanje (merge) dva podniza - deo merge sort algoritma
    public static void merge(ArrayList<Integer> niz, int levo, int sredina, int desno) {
        int n1 = sredina - levo + 1;
        int n2 = desno - sredina;

        // Privremeni nizovi za levi i desni podniz
        ArrayList<Integer> leviPodniz = new ArrayList<>(n1);
        ArrayList<Integer> desniPodniz = new ArrayList<>(n2);

        // Kopiramo podatke u privremene podnizove
        for (int i = 0; i < n1; i++) {
            leviPodniz.add(niz.get(levo + i));
        }
        for (int j = 0; j < n2; j++) {
            desniPodniz.add(niz.get(sredina + 1 + j));
        }

        // Spajamo podnizove nazad u glavni niz
        int i = 0, j = 0, k = levo;
        while (i < n1 && j < n2) {
            if (leviPodniz.get(i) <= desniPodniz.get(j)) {
                niz.set(k, leviPodniz.get(i));
                i++;
            } else {
                niz.set(k, desniPodniz.get(j));
                j++;
            }
            k++;
        }

        // Kopiramo preostale elemente ako ih ima u levom podnizu
        while (i < n1) {
            niz.set(k, leviPodniz.get(i));
            i++;
            k++;
        }

        // Kopiramo preostale elemente ako ih ima u desnom podnizu
        while (j < n2) {
            niz.set(k, desniPodniz.get(j));
            j++;
            k++;
        }
    }

    // Rekurzivna funkcija za merge sort
    public static void mergeSort(ArrayList<Integer> niz, int levo, int desno) {
        if (levo < desno) {
            int sredina = levo + (desno - levo) / 2;

            mergeSort(niz, levo, sredina);      // Sortiramo levi deo
            mergeSort(niz, sredina + 1, desno); // Sortiramo desni deo
            merge(niz, levo, sredina, desno);   // Spajamo sortirane delove
        }
    }

    // Funkcija za binarnu pretragu
    public static int binarnaPretraga(ArrayList<Integer> niz, int levi, int desni, int element) {
        while (levi <= desni) {
            int sredina = levi + (desni - levi) / 2;

            // Proveravamo da li je element na sredini
            if (niz.get(sredina) == element) {
                return sredina;  // Element pronađen, vraćamo indeks
            }

            // Ako je element manji od srednjeg, tražimo u levom delu
            if (niz.get(sredina) > element) {
                desni = sredina - 1;
            } else { // Ako je element veći od srednjeg, tražimo u desnom delu
                levi = sredina + 1;
            }
        }
        return -1; // Element nije pronađen
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = unosBrojaElemenata(scanner);
        ArrayList<Integer> niz = unosElemenata(scanner, n);

        // Sortiranje niza koristeći merge sort
        mergeSort(niz, 0, n - 1);

        // Ispisujemo sortirani niz
        System.out.println("Sortiran niz u rastucem poretku:");
        for (int broj : niz) {
            System.out.print(broj + " ");
        }
        System.out.println();

        // Pretraga elementa koristeći binarnu pretragu
        System.out.print("Unesite element koji zelite da pronadjete: ");
        int trazeniElement = scanner.nextInt();

        int pozicija = binarnaPretraga(niz, 0, n - 1, trazeniElement);

        if (pozicija != -1) {
            System.out.println("Element " + trazeniElement + " je pronadjen na poziciji " + (pozicija + 1) + " (indeks " + pozicija + ").");
        } else {
            System.out.println("Element " + trazeniElement + " nije pronadjen u nizu.");
        }

        scanner.close();
    }
}