#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

/*  TEKST ZADATKA:

    Zadatak: Maksimizacija broja studenata na predavanjima

    Data je lista predavanja, gde svako predavanje ima određeno početno i završno vreme, kao i broj studenata koji prisustvuju tom predavanju. Predavanja su vremenski određena, što znači da se jedno predavanje ne može održavati u isto vreme kada i drugo (preklapanje nije dozvoljeno, osim ako se jedno završava u trenutku kada drugo počinje).

    Vaš zadatak je da pronađete podskup predavanja tako da:

    Nema preklapanja između odabranih predavanja.
    Maksimizujete ukupan broj studenata koji prisustvuju izabranim predavanjima.

*/

// Struktura za predstavljanje predavanja
struct Predavanje {
    int pocetak, kraj, brojStudenata;
};

// Funkcija za poređenje predavanja po vremenu završetka - koristi se za sortiranje
bool porediPoKraju(const Predavanje &a, const Predavanje &b) {
    return a.kraj < b.kraj;
}

// Funkcija za pronalaženje najbližeg predavanja koje ne preklapa sa trenutnim
int nadjiPrethodnoPredavanje(const vector<Predavanje> &predavanja, int j) {
    for (int i = j - 1; i >= 0; i--) {
        if (predavanja[i].kraj <= predavanja[j].pocetak) {
            return i;
        }
    }
    return -1;  // Vraćamo -1 ako nema takvog predavanja
}

// Funkcija za maksimizaciju broja studenata koristeći dinamičko programiranje
int maksimalanBrojStudenata(const vector<Predavanje> &predavanja) {
    int n = predavanja.size();
    vector<int> dp(n);  // dp[i] - maksimalan broj studenata za prvih i predavanja

    // Inicijalizacija: prvi element dp niza je broj studenata u prvom predavanju
    dp[0] = predavanja[0].brojStudenata;

    // Popunjavanje dp niza
    for (int j = 1; j < n; j++) {
        // Opcija 1: Ne uključujemo ovo predavanje
        int bezJ = dp[j - 1];

        // Opcija 2: Uključujemo ovo predavanje, pronalazimo najbliže kompatibilno predavanje
        int saJ = predavanja[j].brojStudenata;
        int prethodno = nadjiPrethodnoPredavanje(predavanja, j);
        if (prethodno != -1) {
            saJ += dp[prethodno];
        }

        // Maksimizujemo broj studenata za predavanja do j-tog predavanja
        dp[j] = max(bezJ, saJ);
    }

    // Rezultat je maksimalan broj studenata za sva predavanja
    return dp[n - 1];
}

int main() {
    int n;
    cout << "Unesite broj predavanja: ";
    cin >> n;

    // Unos predavanja
    vector<Predavanje> predavanja(n);
    for (int i = 0; i < n; i++) {
        cout << "Unesite pocetak, kraj i broj studenata za predavanje " << i + 1 << ": ";
        cin >> predavanja[i].pocetak >> predavanja[i].kraj >> predavanja[i].brojStudenata;
    }

    // Sortiramo predavanja po vremenu završetka
    sort(predavanja.begin(), predavanja.end(), porediPoKraju);

    // Pronalazimo maksimalan broj studenata koristeći dinamičko programiranje
    int rezultat = maksimalanBrojStudenata(predavanja);
    cout << "Maksimalan broj studenata koji mogu prisustvovati predavanjima je: " << rezultat << endl;

    return 0;
}

/// Ispod se nalaze test primeri sa obljasnjenima

/*
    Primer 1:
    Unesite broj predavanja: 4
    Unesite pocetak, kraj i broj studenata za predavanje 1: 1 3 50
    Unesite pocetak, kraj i broj studenata za predavanje 2: 2 5 20
    Unesite pocetak, kraj i broj studenata za predavanje 3: 4 6 70
    Unesite pocetak, kraj i broj studenata za predavanje 4: 6 7 60


    Koraci algoritma
    Sortiranje po vremenu završetka:

    Predavanja su već sortirana prema vremenu završetka, tako da možemo direktno nastaviti.
    Popunjavanje dp niza:

    Koristimo dp niz gde dp[j] predstavlja maksimalan broj studenata do predavanja j, uključujući sve prethodne predavanja koja se ne preklapaju.

    Računamo dp niz za svako predavanje:

    Predavanje 1:
    Samo predavanje 1, dakle dp[0] = 50.
    Predavanje 2:
    Dve opcije:
    Bez uključivanja predavanja 2: dp[1] = dp[0] = 50
    Uključivanje predavanja 2: dp[1] = 20 (samo predavanje 2 jer se preklapa sa predavanjem 1)
    Maksimalna vrednost je dp[1] = 50.
    Predavanje 3:
    Dve opcije:
    Bez uključivanja predavanja 3: dp[2] = dp[1] = 50
    Uključivanje predavanja 3 sa prethodnim kompatibilnim predavanjem (predavanje 1): dp[2] = 70 + 50 = 120
    Maksimalna vrednost je dp[2] = 120.
    Predavanje 4:
    Dve opcije:
    Bez uključivanja predavanja 4: dp[3] = dp[2] = 120
    Uključivanje predavanja 4 sa prethodnim kompatibilnim predavanjem (predavanje 3): dp[3] = 70 + 120 = 190
    Maksimalna vrednost je dp[3] = 190.
    Rezultat:

    Maksimalan broj studenata koji mogu prisustvovati predavanjima je 190.


    Primer 2:

    Unesite broj predavanja: 5
    Unesite pocetak, kraj i broj studenata za predavanje 1: 1 4 40
    Unesite pocetak, kraj i broj studenata za predavanje 2: 3 5 50
    Unesite pocetak, kraj i broj studenata za predavanje 3: 0 6 60
    Unesite pocetak, kraj i broj studenata za predavanje 4: 5 7 30
    Unesite pocetak, kraj i broj studenata za predavanje 5: 8 9 45
    Maksimalan broj studenata koji mogu prisustvovati predavanjima je: 125

    Sortiranje po vremenu završetka:

    Algoritam prvo sortira predavanja po vremenu završetka, kako bi osigurao da prilikom obrade predavanja 𝑗
    j, sva prethodna predavanja završavaju pre ili u isto vreme.


    Računanje dp niza za maksimalan broj studenata do svakog predavanja:

    Koristimo dp niz gde dp[j] predstavlja maksimalan broj studenata do predavanja j, uključujući sve prethodne kompatibilne kombinacije predavanja.

    Predavanje 1:

    Pošto je prvo predavanje, maksimalan broj studenata koji mogu prisustvovati je upravo broj studenata na ovom predavanju.
    Dakle, dp[0] = 40.
    Predavanje 2:

    Dve opcije:
    Opcija 1: Ne uključujemo predavanje 2, već zadržavamo prethodni maksimum, tj. dp[1] = dp[0] = 40.
    Opcija 2: Uključujemo predavanje 2. Pošto se ono preklapa sa predavanjem 1, ne možemo ih uključiti zajedno. Dakle, u ovom slučaju, broj studenata je samo za predavanje 2: dp[1] = 50.
    Maksimalna vrednost za dp[1] je max(40, 50) = 50.
    Predavanje 3:

    Dve opcije:
    Opcija 1: Ne uključujemo predavanje 3, pa ostaje dp[2] = dp[1] = 50.
    Opcija 2: Uključujemo predavanje 3. Budući da se predavanje 3 preklapa sa predavanjima 1 i 2, ono može biti jedino predavanje u ovoj kombinaciji. Dakle, dp[2] = 60.
    Maksimalna vrednost za dp[2] je max(50, 60) = 60.
    Predavanje 4:

    Dve opcije:
    Opcija 1: Ne uključujemo predavanje 4, pa ostaje dp[3] = dp[2] = 60.
    Opcija 2: Uključujemo predavanje 4. Kompatibilno je sa predavanjem 2, tako da se mogu kombinovati.
    Dakle, dp[3] = 30 + 50 = 80.
    Maksimalna vrednost za dp[3] je max(60, 80) = 80.
    Predavanje 5:

    Dve opcije:
    Opcija 1: Ne uključujemo predavanje 5, pa ostaje dp[4] = dp[3] = 80.
    Opcija 2: Uključujemo predavanje 5. Ono se ne preklapa sa prethodnim predavanjem 4, tako da se može kombinovati sa maksimalnim brojem studenata iz dp[3].
    Dakle, dp[4] = 45 + 80 = 125.
    Maksimalna vrednost za dp[4] je max(80, 125) = 125.
    Rezultat:

    Konačni rezultat se nalazi u dp[4], što predstavlja maksimalan broj studenata za optimalan raspored predavanja.

*/
