#include <iostream>
using namespace std;

// Funkcija za unos broja sa zaštitom za neispravan unos
int unosBroja() {
    int n;
    while (true) {
        cout << "Unesite pozitivan ceo broj: ";
        cin >> n;
        if (cin.fail() || n < 0) {  // Provera validnosti unosa
            cin.clear();            // Čistimo grešku ako je unos neispravan
            cin.ignore(10000, '\n'); // Ignorišemo ostatak linije
            cout << "Greska! Molimo unesite pozitivan ceo broj.\n";
        } else {
            return n;  // Izlazimo ako je unos validan
        }
    }
}

// REŠAVANJE HANOJSKIH KULA

// Rekurzivna funkcija za rešavanje problema Hanojskih kula
void hanoi(int diskovi, char pocetak, char kraj, char pomocni) {
    if (diskovi == 1) {
        cout << "Premesti disk 1 sa " << pocetak << " na " << kraj << endl;
        return;
    }
    // Prvi korak: premestamo n-1 diskova sa početnog na pomoćni štap
    hanoi(diskovi - 1, pocetak, pomocni, kraj);
    // Drugi korak: premestamo najveći disk sa početnog na ciljni štap
    cout << "Premesti disk " << diskovi << " sa " << pocetak << " na " << kraj << endl;
    // Treći korak: premestamo n-1 diskova sa pomoćnog na ciljni štap
    hanoi(diskovi - 1, pomocni, kraj, pocetak);
}

// FIBONACI FUNKCIJA

// Rekurzivna funkcija za izračunavanje Fibonacijevog broja
int fibonaci(int n) {
    if (n == 0) return 0;      // Baza: fib(0) = 0
    if (n == 1) return 1;      // Baza: fib(1) = 1
    return fibonaci(n - 1) + fibonaci(n - 2);  // Rekurzivni poziv
}

// FAKTORIJEL FUNKCIJA

// Rekurzivna funkcija za izračunavanje faktorijela
long long faktorijel(int n) {
    if (n <= 1) return 1;  // Baza: faktorijel 0 i 1 je 1
    return n * faktorijel(n - 1);  // Rekurzivni poziv: n * faktorijel(n - 1)
}

int main() {
    // Hanojske kule
    cout << "===== Hanojske Kule =====\n";
    cout << "Unesite broj diskova: ";
    int brojDiskova = unosBroja();
    hanoi(brojDiskova, 'A', 'C', 'B');  // Pokrećemo Hanojske kule sa štapovima A, B i C

    // Fibonaci
    cout << "\n===== Fibonaci =====\n";
    cout << "Unesite indeks za Fibonacijev broj: ";
    int fibIndeks = unosBroja();
    cout << "Fibonaci broj na poziciji " << fibIndeks << " je " << fibonaci(fibIndeks) << endl;

    // Faktorijel
    cout << "\n===== Faktorijel =====\n";
    cout << "Unesite broj za faktorijel: ";
    int brojZaFaktorijel = unosBroja();
    cout << "Faktorijel broja " << brojZaFaktorijel << " je " << faktorijel(brojZaFaktorijel) << endl;

    return 0;
}
