#include <iostream>
#include <vector>

using namespace std;

// Funkcija za unos broja elemenata sa zaštitom
int unosBrojaElemenata() {
    int n;
    while (true) {
        cout << "Unesite broj elemenata niza: ";
        cin >> n;
        if (cin.fail() || n <= 0) {  // Proveravamo da li je unos validan
            cin.clear();             // Čistimo grešku u slučaju nevalidnog unosa
            cin.ignore(10000, '\n'); // Ignorišemo ostatak linije
            cout << "Greska! Unesite pozitivan ceo broj.\n";
        } else {
            break;  // Izlazimo iz petlje ako je unos ispravan
        }
    }
    return n;
}

// Funkcija za unos elemenata niza sa zaštitom
void unosElemenata(vector<int> &niz, int n) {
    int element;
    for (int i = 0; i < n; ++i) {
        while (true) {
            cout << "Unesite element niza " << i + 1 << ": ";
            cin >> element;
            if (cin.fail()) { // Proveravamo validnost unosa
                cin.clear();
                cin.ignore(10000, '\n');
                cout << "Greska! Unesite broj.\n";
            } else {
                niz.push_back(element);
                break;  // Izlazimo iz petlje ako je unos ispravan
            }
        }
    }
}

// Funkcija za spajanje (merge) dva podniza - deo merge sort algoritma
void merge(vector<int> &niz, int levo, int sredina, int desno) {
    int n1 = sredina - levo + 1;     // Broj elemenata u levom podnizu
    int n2 = desno - sredina;        // Broj elemenata u desnom podnizu

    vector<int> leviPodniz(n1), desniPodniz(n2);

    // Kopiramo podatke u privremene podnizove
    for (int i = 0; i < n1; ++i)
        leviPodniz[i] = niz[levo + i];
    for (int j = 0; j < n2; ++j)
        desniPodniz[j] = niz[sredina + 1 + j];

    // Spajamo podnizove nazad u glavni niz
    int i = 0, j = 0, k = levo;
    while (i < n1 && j < n2) {
        if (leviPodniz[i] <= desniPodniz[j]) {
            niz[k] = leviPodniz[i];
            i++;
        } else {
            niz[k] = desniPodniz[j];
            j++;
        }
        k++;
    }

    // Kopiramo preostale elemente ako ih ima u levom podnizu
    while (i < n1) {
        niz[k] = leviPodniz[i];
        i++;
        k++;
    }

    // Kopiramo preostale elemente ako ih ima u desnom podnizu
    while (j < n2) {
        niz[k] = desniPodniz[j];
        j++;
        k++;
    }
}

// Rekurzivna funkcija za merge sort
void mergeSort(vector<int> &niz, int levo, int desno) {
    if (levo < desno) {
        int sredina = levo + (desno - levo) / 2;

        mergeSort(niz, levo, sredina);       // Sortiramo levi deo
        mergeSort(niz, sredina + 1, desno);  // Sortiramo desni deo
        merge(niz, levo, sredina, desno);    // Spajamo sortirane delove
    }
}

// Funkcija za binarnu pretragu
int binarnaPretraga(const vector<int> &niz, int levi, int desni, int element) {
    while (levi <= desni) {
        int sredina = levi + (desni - levi) / 2; // moze i sa midpoint(levi, desni) da pazimo na prekoracenje

        // Proveravamo da li je element na sredini
        if (niz[sredina] == element) {
            return sredina;  // Element pronađen, vraćamo indeks
        }

        // Ako je element manji od srednjeg, tražimo u levom delu
        if (niz[sredina] > element) {
            desni = sredina - 1;
        } else { // Ako je element veći od srednjeg, tražimo u desnom delu
            levi = sredina + 1;
        }
    }
    return -1; // Element nije pronađen
}

int main() {
    int n = unosBrojaElemenata();
    vector<int> niz;

    // Unos elemenata niza
    unosElemenata(niz, n);

    // Sortiranje niza koristeći merge sort
    mergeSort(niz, 0, n - 1);

    // Ispisujemo sortirani niz
    cout << "Sortiran niz u rastucem poretku: ";
    for (int i = 0; i < n; ++i) {
        cout << niz[i] << " ";
    }
    cout << endl;

    // Pretraga elementa koristeći binarnu pretragu
    int trazeniElement;
    cout << "Unesite element koji zelite da pronadjete: ";
    cin >> trazeniElement;

    int pozicija = binarnaPretraga(niz, 0, n - 1, trazeniElement);

    if (pozicija != -1) {
        cout << "Element " << trazeniElement << " je pronadjen na poziciji " << pozicija + 1 << " (indeks " << pozicija << ").\n";
    } else {
        cout << "Element " << trazeniElement << " nije pronadjen u nizu.\n";
    }

    return 0;
}
